const fs = require("fs");
const pptxgen = require("pptxgenjs");

const manifestPath = process.argv[2];
if (!manifestPath) {
  console.error("Usage: node build_editable_ppt.js manifest.json");
  process.exit(1);
}

const manifest = JSON.parse(fs.readFileSync(manifestPath, "utf8"));
const W = manifest.width;
const H = manifest.height;
const sw = W / 100;
const sh = H / 100;

const pptx = new pptxgen();
pptx.author = "AI + human editable PPT workflow prototype";
pptx.subject = "Editable PPT reconstruction from AI-generated slide-like image";
pptx.title = "Editable PPT Rebuild";
pptx.lang = "ko-KR";
pptx.defineLayout({ name: "SOURCE_RATIO", width: sw, height: sh });
pptx.layout = "SOURCE_RATIO";
pptx.theme = {
  headFontFace: "Malgun Gothic",
  bodyFontFace: "Malgun Gothic",
  lang: "ko-KR",
};
pptx.margin = 0;

const C = {
  bg: "F7F3EE",
  ink: "4E4841",
  soft: "6C625A",
  line: "9A8F84",
};

function nbox(key) {
  const b = manifest.assets[key].normBox;
  return { x: b[0] * sw, y: b[1] * sh, w: b[2] * sw, h: b[3] * sh };
}

function addImg(slide, key) {
  slide.addImage({ path: manifest.assets[key].path, ...nbox(key) });
}

function addText(slide, value, nx, ny, nw, nh, opts = {}) {
  slide.addText(value, {
    x: nx * sw,
    y: ny * sh,
    w: nw * sw,
    h: nh * sh,
    margin: 0,
    fit: "shrink",
    fontFace: opts.fontFace || "Malgun Gothic",
    fontSize: opts.fontSize || 10,
    bold: !!opts.bold,
    color: opts.color || C.ink,
    charSpace: opts.charSpace ?? 0,
    align: opts.align || "left",
    valign: opts.valign || "top",
    breakLine: false,
    lineSpacingMultiple: opts.lineSpacingMultiple || 1.05,
  });
}

function addLine(slide, nx1, ny1, nx2, ny2, color = C.line, width = 0.8) {
  slide.addShape(pptx.ShapeType.line, {
    x: nx1 * sw,
    y: ny1 * sh,
    w: (nx2 - nx1) * sw,
    h: (ny2 - ny1) * sh,
    line: { color, width },
  });
}

function sectionTitle(slide, label, nx, ny) {
  addText(slide, label, nx, ny, 0.14, 0.026, {
    fontSize: 9,
    charSpace: 3,
    color: C.ink,
  });
  addLine(slide, nx, ny + 0.027, nx + 0.012, ny + 0.027, C.line, 0.8);
}

function addBullets(slide, lines, nx, ny, nw, nh, fs = 8) {
  const rich = [];
  lines.forEach((line, idx) => {
    rich.push({ text: "• ", options: { color: C.ink } });
    rich.push({ text: line + (idx < lines.length - 1 ? "\n" : ""), options: { color: C.ink } });
  });
  slide.addText(rich, {
    x: nx * sw,
    y: ny * sh,
    w: nw * sw,
    h: nh * sh,
    margin: 0,
    fit: "shrink",
    fontFace: "Malgun Gothic",
    fontSize: fs,
    color: C.ink,
    valign: "top",
    paraSpaceAfterPt: 4,
  });
}

function addAllCrops(slide) {
  [
    "hero_building",
    "brick_large",
    "window_detail",
    "balcony_detail",
    "mat_brick",
    "mat_window",
    "mat_wood",
    "mat_stone",
    "mat_plaster",
    "pal_ivory",
    "pal_sand",
    "pal_warm_beige",
    "pal_taupe",
    "pal_warm_gray",
    "pal_deep_taupe",
  ].forEach((key) => addImg(slide, key));
}

{
  const slide = pptx.addSlide();
  slide.background = { color: C.bg };
  addAllCrops(slide);

  addText(slide, "Material\nStory", 38 / 1491, 122 / 1055, 190 / 1491, 115 / 1055, {
    fontFace: "Georgia",
    fontSize: 29,
    color: "5B5148",
    lineSpacingMultiple: 0.9,
  });
  addLine(slide, 38 / 1491, 255 / 1055, 77 / 1491, 255 / 1055);

  addText(slide, "따뜻한 질감.\n차분한 도시의 일상.", 38 / 1491, 294 / 1055, 185 / 1491, 55 / 1055, {
    fontSize: 8,
    charSpace: 1.4,
    color: C.soft,
    lineSpacingMultiple: 1.25,
  });
  addText(
    slide,
    "베이지 벽돌\n우드 창호 프레임\n매입형 발코니\n자연 소재\n부드러운 빛",
    38 / 1491,
    690 / 1055,
    170 / 1491,
    118 / 1055,
    { fontSize: 7.2, color: C.soft, lineSpacingMultiple: 1.35 }
  );

  sectionTitle(slide, "CONCEPT", 789 / 1491, 66 / 1055);
  addText(
    slide,
    "자연 소재와 정제된 질감이 만나\n차분하고 오래 머무는 공간을 만듭니다.\n\n부드러운 라이트와 따뜻한 표면감이\n공간의 깊이와 균형을 더합니다.",
    789 / 1491,
    111 / 1055,
    260 / 1491,
    132 / 1055,
    { fontSize: 8.5, color: "5F5750", lineSpacingMultiple: 1.18 }
  );

  sectionTitle(slide, "STRATEGY", 789 / 1491, 280 / 1055);
  addBullets(
    slide,
    [
      "소재의 결을 겹쳐 깊이감 만들기",
      "절제된 팔레트로 안정감 유지",
      "빛과 그림자로 질감 드러내기",
      "재료의 진정성 살리기",
    ],
    789 / 1491,
    327 / 1055,
    270 / 1491,
    170 / 1055,
    8
  );

  sectionTitle(slide, "MATERIALS", 789 / 1491, 602 / 1055);
  [
    ["01. 벽돌", 789 / 1491],
    ["02. 우드 창호", 927 / 1491],
    ["03. 우드 도어", 1065 / 1491],
    ["04. 스톤 타일", 1197 / 1491],
    ["05. 플라스터", 1340 / 1491],
  ].forEach(([label, nx]) =>
    addText(slide, label, nx, 816 / 1055, 130 / 1491, 28 / 1055, {
      fontSize: 7,
      color: C.soft,
      charSpace: 0.6,
    })
  );

  sectionTitle(slide, "PALETTE", 38 / 1491, 863 / 1055);
  [
    ["IVORY", 128 / 1491],
    ["SAND", 371 / 1491],
    ["WARM BEIGE", 586 / 1491],
    ["TAUPE", 850 / 1491],
    ["WARM GRAY", 1095 / 1491],
    ["DEEP TAUPE", 1305 / 1491],
  ].forEach(([label, nx]) =>
    addText(slide, label, nx - 70 / 1491, 1014 / 1055, 140 / 1491, 22 / 1055, {
      fontSize: 6.5,
      align: "center",
      color: C.soft,
      charSpace: 0.4,
    })
  );
}

{
  const slide = pptx.addSlide();
  slide.background = { color: "F4F0EA" };
  slide.addImage({ path: manifest.original, x: 0, y: 0, w: sw, h: sh });
  addText(slide, "REFERENCE / 원본 이미지", 0.02, 0.02, 0.24, 0.03, {
    fontSize: 8,
    color: "FFFFFF",
    bold: true,
  });
}

async function main() {
  await pptx.writeFile({ fileName: manifest.outputPptx });
}

main().catch((err) => {
  console.error(err && err.stack ? err.stack : String(err));
  process.exit(1);
});
