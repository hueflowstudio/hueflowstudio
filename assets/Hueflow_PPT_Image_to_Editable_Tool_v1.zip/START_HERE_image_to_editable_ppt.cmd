@echo off
setlocal

set "PYTHON_EXE=C:\Users\kimyj\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"
set "SCRIPT_DIR=%~dp0"
set "GUI_SCRIPT=%SCRIPT_DIR%ppt_image_to_editable_gui.py"

if not exist "%PYTHON_EXE%" (
  echo Python runtime not found:
  echo %PYTHON_EXE%
  pause
  exit /b 1
)

if not exist "%GUI_SCRIPT%" (
  echo GUI script not found:
  echo %GUI_SCRIPT%
  pause
  exit /b 1
)

"%PYTHON_EXE%" "%GUI_SCRIPT%" %*
if errorlevel 1 pause

endlocal
