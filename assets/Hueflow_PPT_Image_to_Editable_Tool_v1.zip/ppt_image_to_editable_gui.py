from __future__ import annotations

import json
import os
import re
import subprocess
import sys
from datetime import datetime
from pathlib import Path
from tkinter import Tk, filedialog, messagebox

from PIL import Image, ImageDraw, ImageFont


ROOT = Path(__file__).resolve().parent
OUT_ROOT = ROOT / "outputs"
NODE_EXE = Path(r"C:\Users\kimyj\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\bin\node.exe")
NODE_MODULES = Path(r"C:\Users\kimyj\.cache\codex-runtimes\codex-primary-runtime\dependencies\node\node_modules")
BUILDER = ROOT / "build_editable_ppt.js"


# v1 profile: based on the Material Story / architecture moodboard layout.
# Values are normalized from the sample image size so larger/smaller images still work.
PROFILE = {
    "hero_building": (264 / 1491, 30 / 1055, 489 / 1491, 820 / 1055),
    "brick_large": (1072 / 1491, 30 / 1055, 396 / 1491, 328 / 1055),
    "window_detail": (1072 / 1491, 363 / 1055, 153 / 1491, 233 / 1055),
    "balcony_detail": (1260 / 1491, 363 / 1055, 206 / 1491, 233 / 1055),
    "mat_brick": (789 / 1491, 636 / 1055, 126 / 1491, 170 / 1055),
    "mat_window": (927 / 1491, 636 / 1055, 126 / 1491, 170 / 1055),
    "mat_wood": (1065 / 1491, 636 / 1055, 118 / 1491, 170 / 1055),
    "mat_stone": (1197 / 1491, 636 / 1055, 131 / 1491, 170 / 1055),
    "mat_plaster": (1340 / 1491, 636 / 1055, 128 / 1491, 170 / 1055),
    "pal_ivory": (33 / 1491, 900 / 1055, 234 / 1491, 99 / 1055),
    "pal_sand": (270 / 1491, 900 / 1055, 239 / 1491, 99 / 1055),
    "pal_warm_beige": (512 / 1491, 900 / 1055, 235 / 1491, 99 / 1055),
    "pal_taupe": (750 / 1491, 900 / 1055, 236 / 1491, 99 / 1055),
    "pal_warm_gray": (989 / 1491, 900 / 1055, 236 / 1491, 99 / 1055),
    "pal_deep_taupe": (1228 / 1491, 900 / 1055, 237 / 1491, 99 / 1055),
}


def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", name).strip("._-")
    return cleaned or "ppt_image"


def pick_image() -> Path | None:
    root = Tk()
    root.withdraw()
    root.update()
    selected = filedialog.askopenfilename(
        title="PPT처럼 분해할 이미지 선택",
        filetypes=[
            ("Image files", "*.jpg *.jpeg *.png *.tif *.tiff *.bmp"),
            ("All files", "*.*"),
        ],
    )
    root.destroy()
    return Path(selected) if selected else None


def show_info(title: str, body: str) -> None:
    root = Tk()
    root.withdraw()
    messagebox.showinfo(title, body)
    root.destroy()


def show_error(title: str, body: str) -> None:
    root = Tk()
    root.withdraw()
    messagebox.showerror(title, body)
    root.destroy()


def to_box(norm_box, width: int, height: int):
    x, y, w, h = norm_box
    left = round(x * width)
    top = round(y * height)
    right = round((x + w) * width)
    bottom = round((y + h) * height)
    left = max(0, min(left, width - 1))
    top = max(0, min(top, height - 1))
    right = max(left + 1, min(right, width))
    bottom = max(top + 1, min(bottom, height))
    return left, top, right, bottom


def crop_assets(image_path: Path, outdir: Path) -> dict:
    img = Image.open(image_path).convert("RGB")
    width, height = img.size
    assets_dir = outdir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)

    assets = {}
    for key, norm_box in PROFILE.items():
        box = to_box(norm_box, width, height)
        crop = img.crop(box)
        asset_path = assets_dir / f"{key}.png"
        crop.save(asset_path)
        assets[key] = {
            "path": str(asset_path),
            "boxPx": box,
            "normBox": norm_box,
        }

    original_path = outdir / "00_original_reference.png"
    img.save(original_path)

    return {
        "source": str(image_path),
        "original": str(original_path),
        "width": width,
        "height": height,
        "assets": assets,
        "outputPptx": str(outdir / "editable_ppt_rebuild_v1.pptx"),
    }


def make_preview(manifest: dict, preview_path: Path) -> None:
    width = manifest["width"]
    height = manifest["height"]
    canvas = Image.new("RGB", (width, height), "#F7F3EE")
    draw = ImageDraw.Draw(canvas)

    def place(key):
        asset = manifest["assets"][key]
        l, t, r, b = asset["boxPx"]
        im = Image.open(asset["path"]).convert("RGB").resize((r - l, b - t), Image.Resampling.LANCZOS)
        canvas.paste(im, (l, t))

    for key in [
        "hero_building",
        "brick_large",
        "window_detail",
        "balcony_detail",
        "mat_brick",
        "mat_window",
        "mat_wood",
        "mat_stone",
        "mat_plaster",
        "pal_ivory",
        "pal_sand",
        "pal_warm_beige",
        "pal_taupe",
        "pal_warm_gray",
        "pal_deep_taupe",
    ]:
        place(key)

    try:
        malgun = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(10, round(width * 0.010)))
        title_font = ImageFont.truetype(r"C:\Windows\Fonts\georgia.ttf", max(28, round(width * 0.031)))
        sec_font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(12, round(width * 0.011)))
    except Exception:
        malgun = ImageFont.load_default()
        title_font = ImageFont.load_default()
        sec_font = ImageFont.load_default()

    ink = "#4E4841"
    soft = "#6C625A"
    line = "#9A8F84"

    def xy(nx, ny):
        return round(nx * width), round(ny * height)

    draw.multiline_text(xy(38 / 1491, 122 / 1055), "Material\nStory", fill="#5B5148", font=title_font, spacing=8)
    x1, y1 = xy(38 / 1491, 255 / 1055)
    x2, y2 = xy(77 / 1491, 255 / 1055)
    draw.line((x1, y1, x2, y2), fill=line, width=1)
    draw.multiline_text(xy(38 / 1491, 294 / 1055), "따뜻한 질감.\n차분한 도시의 일상.", fill=soft, font=malgun, spacing=8)
    draw.multiline_text(
        xy(38 / 1491, 690 / 1055),
        "베이지 벽돌\n우드 창호 프레임\n매입형 발코니\n자연 소재\n부드러운 빛",
        fill=soft,
        font=malgun,
        spacing=8,
    )

    for label, nx, ny in [
        ("CONCEPT", 789 / 1491, 66 / 1055),
        ("STRATEGY", 789 / 1491, 280 / 1055),
        ("MATERIALS", 789 / 1491, 602 / 1055),
        ("PALETTE", 38 / 1491, 863 / 1055),
    ]:
        x, y = xy(nx, ny)
        draw.text((x, y), label, fill=ink, font=sec_font)
        draw.line((x, y + 28, x + 18, y + 28), fill=line, width=1)

    draw.multiline_text(
        xy(789 / 1491, 111 / 1055),
        "자연 소재와 정제된 질감이 만나\n차분하고 오래 머무는 공간을 만듭니다.\n\n부드러운 라이트와 따뜻한 표면감이\n공간의 깊이와 균형을 더합니다.",
        fill="#5F5750",
        font=malgun,
        spacing=8,
    )
    draw.multiline_text(
        xy(789 / 1491, 327 / 1055),
        "• 소재의 결을 겹쳐 깊이감 만들기\n• 절제된 팔레트로 안정감 유지\n• 빛과 그림자로 질감 드러내기\n• 재료의 진정성 살리기",
        fill=ink,
        font=malgun,
        spacing=8,
    )
    for label, nx in [
        ("01. 벽돌", 789 / 1491),
        ("02. 우드 창호", 927 / 1491),
        ("03. 우드 도어", 1065 / 1491),
        ("04. 스톤 타일", 1197 / 1491),
        ("05. 플라스터", 1340 / 1491),
    ]:
        draw.text(xy(nx, 816 / 1055), label, fill=soft, font=malgun)
    for label, nx in [
        ("IVORY", 128 / 1491),
        ("SAND", 371 / 1491),
        ("WARM BEIGE", 586 / 1491),
        ("TAUPE", 850 / 1491),
        ("WARM GRAY", 1095 / 1491),
        ("DEEP TAUPE", 1305 / 1491),
    ]:
        x, y = xy(nx, 1014 / 1055)
        draw.text((x - 30, y), label, fill=soft, font=malgun)
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(preview_path)


def build_ppt(manifest_path: Path) -> subprocess.CompletedProcess[str]:
    env = os.environ.copy()
    env["NODE_PATH"] = str(NODE_MODULES)
    return subprocess.run(
        [str(NODE_EXE), str(BUILDER), str(manifest_path)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        env=env,
    )


def run_job(image_path: Path) -> tuple[dict, Path]:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = OUT_ROOT / f"editable_ppt_{safe_name(image_path.stem)}_{timestamp}"
    outdir.mkdir(parents=True, exist_ok=True)

    manifest = crop_assets(image_path, outdir)
    manifest_path = outdir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    make_preview(manifest, outdir / "preview_rebuild.png")

    result = build_ppt(manifest_path)
    if result.returncode != 0:
        raise RuntimeError(result.stderr or result.stdout or "알 수 없는 오류")
    return manifest, outdir


def main() -> int:
    headless = "--headless" in sys.argv
    args = [arg for arg in sys.argv[1:] if arg != "--headless"]

    if args and Path(args[0]).exists():
        image_path = Path(args[0]).resolve()
    else:
        image_path = pick_image()
    if not image_path:
        return 0

    if not NODE_EXE.exists():
        message = f"Node를 찾을 수 없습니다:\n{NODE_EXE}"
        if headless:
            print(message, file=sys.stderr)
        else:
            show_error("Node 경로 없음", message)
        return 1

    try:
        if not headless:
            show_info(
                "분해 시작",
                "이미지를 PPT에서 고칠 수 있는 형태로 재조립합니다.\n\n"
                "사진/색상칩은 개별 이미지 오브젝트,\n"
                "문장은 편집 가능한 텍스트 박스로 들어갑니다.",
            )
        manifest, outdir = run_job(image_path)
    except Exception as exc:
        if headless:
            print(str(exc), file=sys.stderr)
        else:
            show_error("PPT 생성 실패", str(exc))
        return 1

    if headless:
        print(manifest["outputPptx"])
        print(outdir)
        return 0

    try:
        subprocess.Popen(["explorer", str(outdir)])
    except OSError:
        pass

    show_info(
        "완료",
        "PPT가 생성되었습니다.\n\n"
        f"{manifest['outputPptx']}\n\n"
        "PowerPoint에서 열어서 텍스트와 이미지 오브젝트를 직접 수정해보세요.",
    )
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
