param(
  [Parameter(Mandatory = $true)]
  [string]$ImagePath,

  [Parameter(Mandatory = $true)]
  [string]$OutputJson
)

$ErrorActionPreference = "Stop"

Add-Type -AssemblyName System.Runtime.WindowsRuntime
[void][Windows.Storage.StorageFile, Windows.Storage, ContentType = WindowsRuntime]
[void][Windows.Storage.Streams.IRandomAccessStreamWithContentType, Windows.Storage.Streams, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.BitmapDecoder, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
[void][Windows.Graphics.Imaging.SoftwareBitmap, Windows.Graphics.Imaging, ContentType = WindowsRuntime]
[void][Windows.Media.Ocr.OcrEngine, Windows.Foundation, ContentType = WindowsRuntime]
[void][Windows.Globalization.Language, Windows.Globalization, ContentType = WindowsRuntime]

$asTaskGeneric = ([System.WindowsRuntimeSystemExtensions].GetMethods() |
  Where-Object {
    $_.Name -eq "AsTask" -and $_.IsGenericMethod -and $_.GetParameters().Count -eq 1
  })[0]

function Await-WinRt($AsyncOperation, [Type]$ResultType) {
  $asTask = $asTaskGeneric.MakeGenericMethod($ResultType)
  $task = $asTask.Invoke($null, @($AsyncOperation))
  $task.Wait()
  return $task.Result
}

$file = Await-WinRt ([Windows.Storage.StorageFile]::GetFileFromPathAsync($ImagePath)) ([Windows.Storage.StorageFile])
$stream = Await-WinRt ($file.OpenReadAsync()) ([Windows.Storage.Streams.IRandomAccessStreamWithContentType])
$decoder = Await-WinRt ([Windows.Graphics.Imaging.BitmapDecoder]::CreateAsync($stream)) ([Windows.Graphics.Imaging.BitmapDecoder])
$bitmap = Await-WinRt ($decoder.GetSoftwareBitmapAsync()) ([Windows.Graphics.Imaging.SoftwareBitmap])

$engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromUserProfileLanguages()
if ($null -eq $engine) {
  $engine = [Windows.Media.Ocr.OcrEngine]::TryCreateFromLanguage([Windows.Globalization.Language]::new("en"))
}
if ($null -eq $engine) {
  throw "Windows OCR engine is not available on this PC."
}

$result = Await-WinRt ($engine.RecognizeAsync($bitmap)) ([Windows.Media.Ocr.OcrResult])

$lines = @()
foreach ($line in $result.Lines) {
  if ([string]::IsNullOrWhiteSpace($line.Text)) {
    continue
  }

  $minX = [double]::PositiveInfinity
  $minY = [double]::PositiveInfinity
  $maxX = 0.0
  $maxY = 0.0
  $words = @()

  foreach ($word in $line.Words) {
    $r = $word.BoundingRect
    $minX = [Math]::Min($minX, [double]$r.X)
    $minY = [Math]::Min($minY, [double]$r.Y)
    $maxX = [Math]::Max($maxX, [double]$r.X + [double]$r.Width)
    $maxY = [Math]::Max($maxY, [double]$r.Y + [double]$r.Height)
    $words += [pscustomobject]@{
      text = $word.Text
      x = [Math]::Round([double]$r.X, 2)
      y = [Math]::Round([double]$r.Y, 2)
      w = [Math]::Round([double]$r.Width, 2)
      h = [Math]::Round([double]$r.Height, 2)
    }
  }

  if ($words.Count -eq 0) {
    continue
  }

  $lines += [pscustomobject]@{
    text = $line.Text
    x = [Math]::Round($minX, 2)
    y = [Math]::Round($minY, 2)
    w = [Math]::Round($maxX - $minX, 2)
    h = [Math]::Round($maxY - $minY, 2)
    words = $words
  }
}

$payload = [pscustomobject]@{
  engine = "Windows.Media.Ocr"
  lineCount = $lines.Count
  lines = $lines
}

$json = $payload | ConvertTo-Json -Depth 8
[System.IO.File]::WriteAllText($OutputJson, $json, [System.Text.Encoding]::UTF8)
