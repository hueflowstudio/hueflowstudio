친구에게 보내는 버전 안내 - 이미지에서 수정 가능한 PPT 만들기 v3

왜 오류가 났나요?
  예전 압축본은 만든 사람 PC의 Codex 전용 Python 경로를 직접 보고 있었습니다.
  그래서 다른 PC에서는 C:\Users\kimyj\... 경로가 없어서 "Python runtime not found"가 뜬 것입니다.

처음 1번만 할 일
  1. 압축을 풉니다. zip 안에서 바로 실행하지 말고 폴더로 풀어주세요.
  2. SETUP_FIRST_install_requirements.cmd 를 더블클릭합니다.
  3. Python이 없다고 뜨면 Python 3.11 이상을 설치합니다.
     설치할 때 "Add python.exe to PATH" 체크가 중요합니다.
  4. Node.js가 없다고 뜨면 Node.js LTS를 설치합니다.
  5. 다시 SETUP_FIRST_install_requirements.cmd 를 실행합니다.

사용법
  1. START_HERE_image_to_editable_ppt.cmd 를 더블클릭합니다.
  2. PPT처럼 생긴 이미지를 선택합니다.
  3. 결과 폴더가 열리면 editable_ppt_rebuild_v3.pptx 를 엽니다.

결과물
  - 일반 무드보드형: OCR 글자 분리본 + 건축 무드보드형 재조립본 + 원본 참고 이미지
  - 병원 전략/4분할 카드형: 카드 재구성본 + 원본 참고 이미지

주의
  v3는 건축/인테리어 무드보드형 이미지와 병원 전략 4분할 카드형 이미지를 우선 지원합니다.
  Windows 기본 OCR로 이미지 안의 글자를 읽어 editable text로 얹습니다.
  OCR은 오타가 날 수 있고, 복잡한 사진 위 글자는 지운 흔적이 남을 수 있습니다.
