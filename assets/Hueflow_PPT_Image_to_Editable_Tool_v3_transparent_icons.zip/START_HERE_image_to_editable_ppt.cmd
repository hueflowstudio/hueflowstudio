@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "GUI_SCRIPT=%SCRIPT_DIR%ppt_image_to_editable_gui.py"
set "LOCAL_PY=%SCRIPT_DIR%runtime\python\python.exe"
set "CODEX_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if not exist "%GUI_SCRIPT%" (
  echo GUI script not found:
  echo %GUI_SCRIPT%
  pause
  exit /b 1
)

if exist "%LOCAL_PY%" (
  "%LOCAL_PY%" "%GUI_SCRIPT%" %*
  if errorlevel 1 pause
  exit /b %ERRORLEVEL%
)

if exist "%CODEX_PY%" (
  "%CODEX_PY%" "%GUI_SCRIPT%" %*
  if errorlevel 1 pause
  exit /b %ERRORLEVEL%
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 "%GUI_SCRIPT%" %*
  if errorlevel 1 pause
  exit /b %ERRORLEVEL%
)

where python >nul 2>nul
if not errorlevel 1 (
  python "%GUI_SCRIPT%" %*
  if errorlevel 1 pause
  exit /b %ERRORLEVEL%
)

echo Python was not found on this PC.
echo.
echo Run SETUP_FIRST_install_requirements.cmd after installing Python 3.11 or newer.
echo Python download: https://www.python.org/downloads/windows/
echo.
pause
exit /b 1

endlocal
