@echo off
setlocal

set "SCRIPT_DIR=%~dp0"
set "LOCAL_PY=%SCRIPT_DIR%runtime\python\python.exe"
set "CODEX_PY=%USERPROFILE%\.cache\codex-runtimes\codex-primary-runtime\dependencies\python\python.exe"

if exist "%LOCAL_PY%" (
  "%LOCAL_PY%" -m pip install --upgrade pip pillow
  goto npm_setup
)

if exist "%CODEX_PY%" (
  "%CODEX_PY%" -m pip install --upgrade pip pillow
  goto npm_setup
)

where py >nul 2>nul
if not errorlevel 1 (
  py -3 -m pip install --upgrade pip pillow
  goto npm_setup
)

where python >nul 2>nul
if not errorlevel 1 (
  python -m pip install --upgrade pip pillow
  goto npm_setup
)

echo Python was not found on this PC.
echo Please install Python 3.11 or newer first.
echo During install, check "Add python.exe to PATH".
echo Download: https://www.python.org/downloads/windows/
echo.
pause
exit /b 1

:npm_setup
where npm >nul 2>nul
if errorlevel 1 (
  echo.
  echo Node.js was not found on this PC.
  echo Please install Node.js LTS, then run this setup again.
  echo Download: https://nodejs.org/
  echo.
  pause
  exit /b 1
)

pushd "%SCRIPT_DIR%"
npm install pptxgenjs
popd

echo.
echo Setup finished. Now run START_HERE_image_to_editable_ppt.cmd
pause
exit /b 0

endlocal
