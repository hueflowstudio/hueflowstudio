from __future__ import annotations

import json
import os
import re
import shutil
import subprocess
import sys
import warnings
from datetime import datetime
from pathlib import Path
from tkinter import Tk, filedialog, messagebox

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont, ImageOps

warnings.filterwarnings("ignore", category=DeprecationWarning)


ROOT = Path(__file__).resolve().parent
OUT_ROOT = ROOT / "outputs"
LOCAL_NODE_EXE = ROOT / "runtime" / "node" / "bin" / "node.exe"
CODEX_NODE_EXE = Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies" / "node" / "bin" / "node.exe"
LOCAL_NODE_MODULES = ROOT / "node_modules"
CODEX_NODE_MODULES = Path.home() / ".cache" / "codex-runtimes" / "codex-primary-runtime" / "dependencies" / "node" / "node_modules"
BUILDER = ROOT / "build_editable_ppt.js"
OCR_SCRIPT = ROOT / "windows_ocr.ps1"


# v1 profile: based on the Material Story / architecture moodboard layout.
# Values are normalized from the sample image size so larger/smaller images still work.
PROFILE = {
    "hero_building": (264 / 1491, 30 / 1055, 489 / 1491, 820 / 1055),
    "brick_large": (1072 / 1491, 30 / 1055, 396 / 1491, 328 / 1055),
    "window_detail": (1072 / 1491, 363 / 1055, 153 / 1491, 233 / 1055),
    "balcony_detail": (1260 / 1491, 363 / 1055, 206 / 1491, 233 / 1055),
    "mat_brick": (789 / 1491, 636 / 1055, 126 / 1491, 170 / 1055),
    "mat_window": (927 / 1491, 636 / 1055, 126 / 1491, 170 / 1055),
    "mat_wood": (1065 / 1491, 636 / 1055, 118 / 1491, 170 / 1055),
    "mat_stone": (1197 / 1491, 636 / 1055, 131 / 1491, 170 / 1055),
    "mat_plaster": (1340 / 1491, 636 / 1055, 128 / 1491, 170 / 1055),
    "pal_ivory": (33 / 1491, 900 / 1055, 234 / 1491, 99 / 1055),
    "pal_sand": (270 / 1491, 900 / 1055, 239 / 1491, 99 / 1055),
    "pal_warm_beige": (512 / 1491, 900 / 1055, 235 / 1491, 99 / 1055),
    "pal_taupe": (750 / 1491, 900 / 1055, 236 / 1491, 99 / 1055),
    "pal_warm_gray": (989 / 1491, 900 / 1055, 236 / 1491, 99 / 1055),
    "pal_deep_taupe": (1228 / 1491, 900 / 1055, 237 / 1491, 99 / 1055),
}


STRATEGY_CARD_PROFILE = {
    "referenceWidth": 1366,
    "referenceHeight": 768,
    "cards": [
        {
            "id": "luminous_facade",
            "title": "Luminous Facade",
            "floor": "(1F)",
            "iconBox": (36, 48, 238, 215),
            "requestBox": (300, 100, 646, 216),
            "solutionBox": (300, 220, 648, 348),
        },
        {
            "id": "seamless_transport",
            "title": "Seamless Transport",
            "floor": "(Elevator)",
            "iconBox": (760, 62, 958, 218),
            "requestBox": (995, 108, 1332, 215),
            "solutionBox": (995, 220, 1334, 348),
        },
        {
            "id": "adaptive_healing",
            "title": "Adaptive Healing Core",
            "floor": "(6F)",
            "iconBox": (38, 438, 250, 625),
            "requestBox": (300, 505, 648, 617),
            "solutionBox": (300, 620, 648, 744),
        },
        {
            "id": "operational_efficiency",
            "title": "Operational Efficiency",
            "floor": "(4-5F)",
            "iconBox": (768, 448, 958, 620),
            "requestBox": (995, 506, 1332, 604),
            "solutionBox": (995, 620, 1334, 744),
        },
    ],
}


def safe_name(name: str) -> str:
    cleaned = re.sub(r"[^0-9A-Za-z가-힣_-]+", "_", name).strip("._-")
    return cleaned or "ppt_image"


def pick_image() -> Path | None:
    root = Tk()
    root.withdraw()
    root.update()
    selected = filedialog.askopenfilename(
        title="PPT처럼 분해할 이미지 선택",
        filetypes=[
            ("Image files", "*.jpg *.jpeg *.png *.tif *.tiff *.bmp"),
            ("All files", "*.*"),
        ],
    )
    root.destroy()
    return Path(selected) if selected else None


def show_info(title: str, body: str) -> None:
    root = Tk()
    root.withdraw()
    messagebox.showinfo(title, body)
    root.destroy()


def show_error(title: str, body: str) -> None:
    root = Tk()
    root.withdraw()
    messagebox.showerror(title, body)
    root.destroy()


def to_box(norm_box, width: int, height: int):
    x, y, w, h = norm_box
    left = round(x * width)
    top = round(y * height)
    right = round((x + w) * width)
    bottom = round((y + h) * height)
    left = max(0, min(left, width - 1))
    top = max(0, min(top, height - 1))
    right = max(left + 1, min(right, width))
    bottom = max(top + 1, min(bottom, height))
    return left, top, right, bottom


def rgb_to_hex(rgb: tuple[int, int, int]) -> str:
    return f"{rgb[0]:02X}{rgb[1]:02X}{rgb[2]:02X}"


def median_rgb(samples: list[tuple[int, int, int]], fallback=(247, 243, 238)) -> tuple[int, int, int]:
    if not samples:
        return fallback
    channels = []
    for idx in range(3):
        values = sorted(px[idx] for px in samples)
        channels.append(values[len(values) // 2])
    return tuple(channels)


def normalize_ocr_text(text: str) -> str:
    replacements = {
        "커피습": "커피숍",
        "켜셔": "켜져",
        "전연": "전면",
        "이간": "야간",
        "건측적": "건축적",
        "솔루선": "솔루션",
        "습루션": "솔루션",
        "이승": "이송",
        "경상": "병상",
        "효을": "효율",
        "병등": "병동",
        "최직화": "최적화",
        "SeamIess": "Seamless",
        "EIevator": "Elevator",
        "관S": "관통",
    }
    cleaned = text.strip()
    for wrong, right in replacements.items():
        cleaned = cleaned.replace(wrong, right)
    return cleaned


def expanded_box(line: dict, width: int, height: int, factor: float = 0.38):
    pad = max(3, round(float(line["h"]) * factor))
    left = max(0, round(float(line["x"]) - pad))
    top = max(0, round(float(line["y"]) - pad))
    right = min(width, round(float(line["x"]) + float(line["w"]) + pad))
    bottom = min(height, round(float(line["y"]) + float(line["h"]) + pad))
    return left, top, right, bottom


def sample_ring_color(img: Image.Image, box: tuple[int, int, int, int]) -> tuple[int, int, int]:
    width, height = img.size
    left, top, right, bottom = box
    ring = []
    margin = max(4, (bottom - top) // 2)

    sample_boxes = [
        (left, max(0, top - margin), right, top),
        (left, bottom, right, min(height, bottom + margin)),
        (max(0, left - margin), top, left, bottom),
        (right, top, min(width, right + margin), bottom),
    ]

    for sx1, sy1, sx2, sy2 in sample_boxes:
        if sx2 <= sx1 or sy2 <= sy1:
            continue
        crop = img.crop((sx1, sy1, sx2, sy2)).resize((max(1, min(60, sx2 - sx1)), max(1, min(24, sy2 - sy1))))
        ring.extend(list(crop.getdata()))
    return median_rgb(ring)


def estimate_text_color(img: Image.Image, line: dict, bg: tuple[int, int, int]) -> str:
    width, height = img.size
    left = max(0, round(float(line["x"])))
    top = max(0, round(float(line["y"])))
    right = min(width, round(float(line["x"]) + float(line["w"])))
    bottom = min(height, round(float(line["y"]) + float(line["h"])))
    if right <= left or bottom <= top:
        return "4E4841"

    crop = img.crop((left, top, right, bottom)).resize((max(1, min(140, right - left)), max(1, min(40, bottom - top))))
    pixels = list(crop.getdata())
    bg_luma = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]
    scored = []
    for px in pixels:
        luma = 0.299 * px[0] + 0.587 * px[1] + 0.114 * px[2]
        dist = abs(px[0] - bg[0]) + abs(px[1] - bg[1]) + abs(px[2] - bg[2])
        scored.append((luma, dist, px))

    if bg_luma >= 145:
        candidates = [px for luma, dist, px in scored if luma < bg_luma - 28 and dist > 35]
        if len(candidates) > 4:
            candidates = sorted(candidates, key=lambda p: 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2])[: max(5, len(candidates) // 2)]
            return rgb_to_hex(median_rgb(candidates, fallback=(78, 72, 65)))
    else:
        candidates = [px for luma, dist, px in scored if luma > bg_luma + 28 and dist > 35]
        if len(candidates) > 4:
            candidates = sorted(candidates, key=lambda p: 0.299 * p[0] + 0.587 * p[1] + 0.114 * p[2], reverse=True)[: max(5, len(candidates) // 2)]
            return rgb_to_hex(median_rgb(candidates, fallback=(245, 245, 245)))

    farthest = [px for _luma, dist, px in sorted(scored, key=lambda item: item[1], reverse=True)[: max(5, len(scored) // 5)] if dist > 35]
    if len(farthest) < 5:
        return "4E4841"
    return rgb_to_hex(median_rgb(farthest, fallback=(78, 72, 65)))


def classify_ocr_line(text: str, h: float, y: float) -> str:
    stripped = text.strip()
    letters = [ch for ch in stripped if ch.isalpha()]
    upper_ratio = sum(1 for ch in letters if ch.upper() == ch) / max(1, len(letters))
    if h >= 25 or (y < 250 and h >= 18):
        return "title"
    if len(stripped) <= 22 and upper_ratio > 0.78:
        return "section"
    if h <= 11 and upper_ratio > 0.65:
        return "label"
    return "body"


def read_windows_ocr(image_path: Path, output_json: Path) -> dict:
    powershell = shutil.which("powershell")
    if not powershell or not OCR_SCRIPT.exists():
        return {"available": False, "engine": None, "lines": [], "error": "Windows OCR script not available"}

    result = subprocess.run(
        [
            powershell,
            "-NoProfile",
            "-ExecutionPolicy",
            "Bypass",
            "-File",
            str(OCR_SCRIPT),
            "-ImagePath",
            str(image_path),
            "-OutputJson",
            str(output_json),
        ],
        capture_output=True,
        text=True,
        timeout=90,
    )
    if result.returncode != 0 or not output_json.exists():
        return {"available": False, "engine": "Windows.Media.Ocr", "lines": [], "error": result.stderr or result.stdout}

    try:
        payload = json.loads(output_json.read_text(encoding="utf-8-sig"))
    except Exception as exc:
        return {"available": False, "engine": "Windows.Media.Ocr", "lines": [], "error": str(exc)}

    return {
        "available": True,
        "engine": payload.get("engine", "Windows.Media.Ocr"),
        "lines": payload.get("lines", []),
        "rawPath": str(output_json),
    }


def run_windows_ocr(image_path: Path, outdir: Path, width: int, height: int) -> dict:
    ocr_json = outdir / "ocr_windows_lines.json"
    payload = read_windows_ocr(image_path, ocr_json)
    if not payload.get("available"):
        return payload

    clean_lines = []
    for line in payload.get("lines", []):
        text = normalize_ocr_text(str(line.get("text", "")).strip())
        if len(text) < 2:
            continue
        x = max(0.0, min(float(line.get("x", 0)), width - 1))
        y = max(0.0, min(float(line.get("y", 0)), height - 1))
        w = max(1.0, min(float(line.get("w", 1)), width - x))
        h = max(1.0, min(float(line.get("h", 1)), height - y))
        if h < 5 or w < 4:
            continue
        role = classify_ocr_line(text, h, y)
        clean_lines.append(
            {
                "text": text,
                "x": round(x, 2),
                "y": round(y, 2),
                "w": round(w, 2),
                "h": round(h, 2),
                "role": role,
                "fontSize": round(max(5.5, min(38.0, h * 0.72)), 1),
                "charSpace": 1.4 if role in {"section", "label"} else 0,
            }
        )

    return {
        "available": True,
        "engine": payload.get("engine", "Windows.Media.Ocr"),
        "lines": clean_lines,
        "rawPath": str(ocr_json),
    }


def crop_ref_box(box: tuple[int, int, int, int], width: int, height: int) -> tuple[int, int, int, int]:
    rw = STRATEGY_CARD_PROFILE["referenceWidth"]
    rh = STRATEGY_CARD_PROFILE["referenceHeight"]
    x1, y1, x2, y2 = box
    return (
        max(0, min(width - 1, round(x1 / rw * width))),
        max(0, min(height - 1, round(y1 / rh * height))),
        max(1, min(width, round(x2 / rw * width))),
        max(1, min(height, round(y2 / rh * height))),
    )


def prepare_ocr_crop(src: Image.Image, box: tuple[int, int, int, int], out_path: Path) -> None:
    crop = src.crop(box)
    scale = 3
    crop = crop.resize((crop.width * scale, crop.height * scale), Image.Resampling.LANCZOS)
    gray = ImageOps.grayscale(crop)
    gray = ImageEnhance.Contrast(gray).enhance(2.2)
    inverted = ImageOps.invert(gray)
    inverted = ImageEnhance.Contrast(inverted).enhance(1.5)
    inverted.save(out_path)


def text_from_ocr_crop(crop_path: Path, json_path: Path) -> list[str]:
    payload = read_windows_ocr(crop_path, json_path)
    lines = []
    for line in payload.get("lines", []):
        text = normalize_ocr_text(str(line.get("text", "")).strip())
        if text and text not in {"1", "|", "-"}:
            lines.append(text)
    return lines


def detect_strategy_card_layout(ocr: dict, img: Image.Image) -> bool:
    if img.width < 900 or img.height < 500:
        return False
    joined = " ".join(line.get("text", "") for line in ocr.get("lines", []))
    signals = ["원장님 요청", "건축적 솔루션", "Luminous Facade", "Operational Efficiency", "Elevator"]
    return sum(1 for signal in signals if signal in joined) >= 2


def build_strategy_cards(image_path: Path, img: Image.Image, outdir: Path, ocr: dict) -> dict | None:
    if not detect_strategy_card_layout(ocr, img):
        return None

    assets_dir = outdir / "assets" / "strategy_cards"
    assets_dir.mkdir(parents=True, exist_ok=True)
    cards = []

    for card in STRATEGY_CARD_PROFILE["cards"]:
        icon_box = crop_ref_box(card["iconBox"], img.width, img.height)
        icon_path = assets_dir / f"{card['id']}_icon.png"
        img.crop(icon_box).save(icon_path)

        request_box = crop_ref_box(card["requestBox"], img.width, img.height)
        solution_box = crop_ref_box(card["solutionBox"], img.width, img.height)

        request_crop = assets_dir / f"{card['id']}_request_ocr.png"
        solution_crop = assets_dir / f"{card['id']}_solution_ocr.png"
        prepare_ocr_crop(img, request_box, request_crop)
        prepare_ocr_crop(img, solution_box, solution_crop)

        request_lines = text_from_ocr_crop(request_crop, assets_dir / f"{card['id']}_request_ocr.json")
        solution_lines = text_from_ocr_crop(solution_crop, assets_dir / f"{card['id']}_solution_ocr.json")

        if request_lines and request_lines[0] == "원장님 요청:":
            request_lines = request_lines[1:]
        if solution_lines and solution_lines[0] in {"건축적 솔루션:", "건축적 솔루션"}:
            solution_lines = solution_lines[1:]

        cards.append(
            {
                "id": card["id"],
                "title": card["title"].replace("Adaptive Healing Core", "Adaptive Healing\nCore").replace(
                    "Operational Efficiency", "Operational\nEfficiency"
                ),
                "floor": card["floor"],
                "icon": str(icon_path),
                "request": "\n".join(request_lines).strip(),
                "solution": "\n".join(solution_lines).strip(),
            }
        )

    return {
        "type": "strategy_cards",
        "title": "층별 핵심 전략",
        "subtitle": "원장님 요청과 건축적 솔루션을 editable 카드로 재구성",
        "cards": cards,
    }


def make_text_removed_image(img: Image.Image, lines: list[dict], out_path: Path) -> Image.Image:
    cleaned = img.copy()
    draw = ImageDraw.Draw(cleaned)
    width, height = cleaned.size

    for line in lines:
        box = expanded_box(line, width, height)
        bg = sample_ring_color(cleaned, box)
        guessed = estimate_text_color(img, line, bg)
        bg_luma = 0.299 * bg[0] + 0.587 * bg[1] + 0.114 * bg[2]
        guessed_rgb = tuple(int(guessed[i : i + 2], 16) for i in (0, 2, 4))
        guessed_luma = 0.299 * guessed_rgb[0] + 0.587 * guessed_rgb[1] + 0.114 * guessed_rgb[2]
        if bg_luma > 145 and guessed_luma > 135:
            guessed = "5B5148" if line.get("role") == "title" else "4E4841"
        line["color"] = guessed
        line["eraseBox"] = box
        draw.rectangle(box, fill=bg)

    # A tiny blur softens hard rectangle edges on paper-like backgrounds.
    mask = Image.new("L", cleaned.size, 0)
    mask_draw = ImageDraw.Draw(mask)
    for line in lines:
        mask_draw.rectangle(tuple(line["eraseBox"]), fill=255)
    blurred = cleaned.filter(ImageFilter.GaussianBlur(radius=0.6))
    cleaned = Image.composite(blurred, cleaned, mask.filter(ImageFilter.GaussianBlur(radius=1.0)))
    cleaned.save(out_path)
    return cleaned


def make_ocr_preview(manifest: dict, preview_path: Path) -> None:
    bg_path = manifest.get("textRemoved")
    if not bg_path:
        return
    canvas = Image.open(bg_path).convert("RGB")
    draw = ImageDraw.Draw(canvas)
    width, height = canvas.size

    try:
        body_font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(8, round(width * 0.008)))
        title_font = ImageFont.truetype(r"C:\Windows\Fonts\georgia.ttf", max(18, round(width * 0.024)))
    except Exception:
        body_font = ImageFont.load_default()
        title_font = ImageFont.load_default()

    for line in manifest.get("ocrLines", []):
        font = title_font if line.get("role") == "title" else body_font
        x = round(line["x"])
        y = round(line["y"])
        color = "#" + line.get("color", "4E4841")
        draw.text((x, y), line["text"], fill=color, font=font)

    preview_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(preview_path)


def crop_assets(image_path: Path, outdir: Path) -> dict:
    img = Image.open(image_path).convert("RGB")
    width, height = img.size
    assets_dir = outdir / "assets"
    assets_dir.mkdir(parents=True, exist_ok=True)

    original_path = outdir / "00_original_reference.png"
    img.save(original_path)

    ocr = run_windows_ocr(image_path, outdir, width, height)
    strategy_rebuild = build_strategy_cards(image_path, img, outdir, ocr)
    text_removed_path = outdir / "00_text_removed_background.png"
    if ocr.get("lines"):
        crop_source = make_text_removed_image(img, ocr["lines"], text_removed_path)
    else:
        crop_source = img.copy()
        crop_source.save(text_removed_path)

    assets = {}
    for key, norm_box in PROFILE.items():
        box = to_box(norm_box, width, height)
        crop = crop_source.crop(box)
        asset_path = assets_dir / f"{key}.png"
        crop.save(asset_path)
        assets[key] = {
            "path": str(asset_path),
            "boxPx": box,
            "normBox": norm_box,
        }

    return {
        "source": str(image_path),
        "original": str(original_path),
        "textRemoved": str(text_removed_path),
        "ocrAvailable": bool(ocr.get("available")),
        "ocrEngine": ocr.get("engine"),
        "ocrError": ocr.get("error"),
        "ocrLines": ocr.get("lines", []),
        "profileType": "strategy_cards" if strategy_rebuild else "material_moodboard",
        "strategyRebuild": strategy_rebuild,
        "width": width,
        "height": height,
        "assets": assets,
        "outputPptx": str(outdir / "editable_ppt_rebuild_v3.pptx"),
    }


def make_preview(manifest: dict, preview_path: Path) -> None:
    width = manifest["width"]
    height = manifest["height"]
    canvas = Image.new("RGB", (width, height), "#F7F3EE")
    draw = ImageDraw.Draw(canvas)

    def place(key):
        asset = manifest["assets"][key]
        l, t, r, b = asset["boxPx"]
        im = Image.open(asset["path"]).convert("RGB").resize((r - l, b - t), Image.Resampling.LANCZOS)
        canvas.paste(im, (l, t))

    for key in [
        "hero_building",
        "brick_large",
        "window_detail",
        "balcony_detail",
        "mat_brick",
        "mat_window",
        "mat_wood",
        "mat_stone",
        "mat_plaster",
        "pal_ivory",
        "pal_sand",
        "pal_warm_beige",
        "pal_taupe",
        "pal_warm_gray",
        "pal_deep_taupe",
    ]:
        place(key)

    try:
        malgun = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(10, round(width * 0.010)))
        title_font = ImageFont.truetype(r"C:\Windows\Fonts\georgia.ttf", max(28, round(width * 0.031)))
        sec_font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(12, round(width * 0.011)))
    except Exception:
        malgun = ImageFont.load_default()
        title_font = ImageFont.load_default()
        sec_font = ImageFont.load_default()

    ink = "#4E4841"
    soft = "#6C625A"
    line = "#9A8F84"

    def xy(nx, ny):
        return round(nx * width), round(ny * height)

    draw.multiline_text(xy(38 / 1491, 122 / 1055), "Material\nStory", fill="#5B5148", font=title_font, spacing=8)
    x1, y1 = xy(38 / 1491, 255 / 1055)
    x2, y2 = xy(77 / 1491, 255 / 1055)
    draw.line((x1, y1, x2, y2), fill=line, width=1)
    draw.multiline_text(xy(38 / 1491, 294 / 1055), "따뜻한 질감.\n차분한 도시의 일상.", fill=soft, font=malgun, spacing=8)
    draw.multiline_text(
        xy(38 / 1491, 690 / 1055),
        "베이지 벽돌\n우드 창호 프레임\n매입형 발코니\n자연 소재\n부드러운 빛",
        fill=soft,
        font=malgun,
        spacing=8,
    )

    for label, nx, ny in [
        ("CONCEPT", 789 / 1491, 66 / 1055),
        ("STRATEGY", 789 / 1491, 280 / 1055),
        ("MATERIALS", 789 / 1491, 602 / 1055),
        ("PALETTE", 38 / 1491, 863 / 1055),
    ]:
        x, y = xy(nx, ny)
        draw.text((x, y), label, fill=ink, font=sec_font)
        draw.line((x, y + 28, x + 18, y + 28), fill=line, width=1)

    draw.multiline_text(
        xy(789 / 1491, 111 / 1055),
        "자연 소재와 정제된 질감이 만나\n차분하고 오래 머무는 공간을 만듭니다.\n\n부드러운 라이트와 따뜻한 표면감이\n공간의 깊이와 균형을 더합니다.",
        fill="#5F5750",
        font=malgun,
        spacing=8,
    )
    draw.multiline_text(
        xy(789 / 1491, 327 / 1055),
        "• 소재의 결을 겹쳐 깊이감 만들기\n• 절제된 팔레트로 안정감 유지\n• 빛과 그림자로 질감 드러내기\n• 재료의 진정성 살리기",
        fill=ink,
        font=malgun,
        spacing=8,
    )
    for label, nx in [
        ("01. 벽돌", 789 / 1491),
        ("02. 우드 창호", 927 / 1491),
        ("03. 우드 도어", 1065 / 1491),
        ("04. 스톤 타일", 1197 / 1491),
        ("05. 플라스터", 1340 / 1491),
    ]:
        draw.text(xy(nx, 816 / 1055), label, fill=soft, font=malgun)
    for label, nx in [
        ("IVORY", 128 / 1491),
        ("SAND", 371 / 1491),
        ("WARM BEIGE", 586 / 1491),
        ("TAUPE", 850 / 1491),
        ("WARM GRAY", 1095 / 1491),
        ("DEEP TAUPE", 1305 / 1491),
    ]:
        x, y = xy(nx, 1014 / 1055)
        draw.text((x - 30, y), label, fill=soft, font=malgun)
    preview_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(preview_path)


def draw_wrapped(draw: ImageDraw.ImageDraw, text: str, xy, font, fill, max_chars: int, spacing: int = 4) -> None:
    lines = []
    for raw in text.splitlines():
        raw = raw.strip()
        if not raw:
            lines.append("")
            continue
        while len(raw) > max_chars:
            cut = raw.rfind(" ", 0, max_chars)
            if cut < max_chars // 2:
                cut = max_chars
            lines.append(raw[:cut].strip())
            raw = raw[cut:].strip()
        lines.append(raw)
    draw.multiline_text(xy, "\n".join(lines), font=font, fill=fill, spacing=spacing)


def make_strategy_preview(manifest: dict, preview_path: Path) -> None:
    data = manifest.get("strategyRebuild")
    if not data:
        return

    width = manifest["width"]
    height = manifest["height"]
    canvas = Image.new("RGB", (width, height), "#07172B")
    draw = ImageDraw.Draw(canvas)

    def sx(v):
        return round(v / 1366 * width)

    def sy(v):
        return round(v / 768 * height)

    try:
        title_font = ImageFont.truetype(r"C:\Windows\Fonts\georgiab.ttf", max(17, round(width * 0.021)))
        floor_font = ImageFont.truetype(r"C:\Windows\Fonts\georgia.ttf", max(14, round(width * 0.017)))
        label_font = ImageFont.truetype(r"C:\Windows\Fonts\malgunbd.ttf", max(10, round(width * 0.010)))
        body_font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(8, round(width * 0.009)))
        small_font = ImageFont.truetype(r"C:\Windows\Fonts\malgun.ttf", max(8, round(width * 0.008)))
    except Exception:
        title_font = floor_font = label_font = body_font = small_font = ImageFont.load_default()

    gold = "#E7B75E"
    light_gold = "#F4D38A"
    white = "#FFFFFF"
    panel = "#0B2038"

    draw.line((sx(683), sy(25), sx(683), sy(743)), fill=gold, width=2)
    draw.line((sx(20), sy(384), sx(1346), sy(384)), fill=gold, width=2)

    layouts = [
        {"icon": (58, 58, 178, 158), "title": (315, 38), "req": (305, 112, 344, 92), "sol": (305, 222, 344, 126)},
        {"icon": (780, 70, 168, 140), "title": (1000, 40), "req": (995, 112, 340, 92), "sol": (995, 222, 340, 126)},
        {"icon": (52, 445, 190, 175), "title": (315, 414), "req": (305, 510, 344, 94), "sol": (305, 620, 344, 124)},
        {"icon": (780, 455, 170, 150), "title": (1000, 414), "req": (995, 510, 340, 94), "sol": (995, 620, 340, 124)},
    ]

    def draw_box(box, label, body, chars):
        x, y, w, h = box
        rect = (sx(x), sy(y), sx(x + w), sy(y + h))
        draw.rounded_rectangle(rect, radius=14, fill=panel, outline=gold, width=2)
        draw.text((sx(x + 18), sy(y + 11)), label, font=label_font, fill=light_gold)
        draw_wrapped(draw, body or "내용을 입력하세요.", (sx(x + 18), sy(y + 35)), body_font, white, chars, spacing=3)

    for card, layout in zip(data.get("cards", []), layouts):
        ix, iy, iw, ih = layout["icon"]
        icon = Image.open(card["icon"]).convert("RGBA")
        icon = icon.resize((sx(iw), sy(ih)), Image.Resampling.LANCZOS)
        canvas.paste(icon, (sx(ix), sy(iy)), icon)

        tx, ty = layout["title"]
        title = card.get("title", "")
        draw_wrapped(draw, title, (sx(tx), sy(ty)), title_font, white, 18, spacing=0)
        floor_y = ty + (62 if "\n" in title else 38)
        draw.text((sx(tx), sy(floor_y)), card.get("floor", ""), font=floor_font, fill=light_gold)
        draw_box(layout["req"], "원장님 요청:", card.get("request", ""), 19)
        draw_box(layout["sol"], "건축적 솔루션:", card.get("solution", ""), 22)

    preview_path.parent.mkdir(parents=True, exist_ok=True)
    canvas.save(preview_path)


def build_ppt(manifest_path: Path) -> subprocess.CompletedProcess[str]:
    node_exe = find_node_exe()
    if node_exe is None:
        raise RuntimeError(
            "Node.js를 찾을 수 없습니다.\n"
            "친구 PC라면 SETUP_FIRST_install_requirements.cmd를 먼저 실행하거나 Node.js LTS를 설치해주세요."
        )

    env = os.environ.copy()
    node_paths = [str(p) for p in [LOCAL_NODE_MODULES, CODEX_NODE_MODULES] if p.exists()]
    if node_paths:
        env["NODE_PATH"] = os.pathsep.join(node_paths)
    return subprocess.run(
        [str(node_exe), str(BUILDER), str(manifest_path)],
        cwd=str(ROOT),
        capture_output=True,
        text=True,
        env=env,
    )


def run_job(image_path: Path) -> tuple[dict, Path]:
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    outdir = OUT_ROOT / f"editable_ppt_{safe_name(image_path.stem)}_{timestamp}"
    outdir.mkdir(parents=True, exist_ok=True)

    manifest = crop_assets(image_path, outdir)
    manifest_path = outdir / "manifest.json"
    manifest_path.write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    make_preview(manifest, outdir / "preview_rebuild.png")
    make_ocr_preview(manifest, outdir / "preview_ocr_text_split.png")
    make_strategy_preview(manifest, outdir / "preview_strategy_cards.png")

    result = build_ppt(manifest_path)
    if result.returncode != 0:
        raise RuntimeError(result.stderr or result.stdout or "알 수 없는 오류")
    return manifest, outdir


def main() -> int:
    headless = "--headless" in sys.argv
    args = [arg for arg in sys.argv[1:] if arg != "--headless"]

    if args and Path(args[0]).exists():
        image_path = Path(args[0]).resolve()
    else:
        image_path = pick_image()
    if not image_path:
        return 0

    try:
        if not headless:
            show_info(
                "분해 시작",
                "이미지를 PPT에서 고칠 수 있는 형태로 재조립합니다.\n\n"
                "사진/색상칩은 개별 이미지 오브젝트,\n"
                "문장은 편집 가능한 텍스트 박스로 들어갑니다.",
            )
        manifest, outdir = run_job(image_path)
    except Exception as exc:
        if headless:
            print(str(exc), file=sys.stderr)
        else:
            show_error("PPT 생성 실패", str(exc))
        return 1

    if headless:
        print(manifest["outputPptx"])
        print(outdir)
        return 0

    try:
        subprocess.Popen(["explorer", str(outdir)])
    except OSError:
        pass

    show_info(
        "완료",
        "PPT가 생성되었습니다.\n\n"
        f"{manifest['outputPptx']}\n\n"
        "PowerPoint에서 열어서 텍스트와 이미지 오브젝트를 직접 수정해보세요.",
    )
    return 0


def find_node_exe() -> Path | None:
    for candidate in [LOCAL_NODE_EXE, CODEX_NODE_EXE]:
        if candidate.exists():
            return candidate
    found = shutil.which("node")
    return Path(found) if found else None


if __name__ == "__main__":
    raise SystemExit(main())
